<?php 

include ("required/db_connection.php");
include ("required/tables.php");
include ("required/functions.php");

$trans_type = $_POST['val1'];

$count_query = "SELECT *,count(*) AS trans_count FROM transactions WHERE particulars LIKE '%$trans_type%'";
$count =  db_one($count_query);
$check_query = "SELECT * FROM transactions WHERE particulars LIKE '%$trans_type%'";

$check_result = db_all($check_query);
    $str = '';
    $str .='<h1>'.$count["trans_count"].'</h1>';
    $str .='<table class="table table-respomnsive table-bordered table-condensed table-hover">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Particulars</th>
                        <th>Withdrawal</th>
                        <th>Deposit</th>
                        <th>Balance</th>
                    </tr>
                    <tbody>';
foreach($check_result AS $ch_row){
    $str .='<tr>
            <td>'.$ch_row['date'].'</td>
            <td>'.$ch_row['particulars'].'</td>
            <td>'.$ch_row['withdrawal'].'</td>
            <td>'.$ch_row['deposit'].'</td>
            <td>'.$ch_row['balance'].'</td>
            </tr>';
}
$str .='</tbody>
    </table>';
echo $str;
?>