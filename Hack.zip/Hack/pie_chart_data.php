<?php
include ("required/db_connection.php");
include ("required/tables.php");
include ("required/functions.php");

$atm_widrawal = "SELECT count(*) AS atm_count FROM transactions WHERE particulars LIKE '%ATM Widrawal%'";
$atm_widrawal_result = db_one($atm_widrawal);

$neft = "SELECT count(*) AS neft_count FROM transactions WHERE particulars LIKE '%NEFT%'";
$neft_result = db_one($neft);

$cash = "SELECT count(*) AS cash_count FROM transactions WHERE particulars LIKE '%Cash%'";
$cash_result = db_one($cash);

$RTGS = "SELECT count(*) AS RTGS_count FROM transactions WHERE particulars LIKE '%RTGS%'";
$RTGS_result = db_one($RTGS);

$UPI = "SELECT count(*) AS UPI_count FROM transactions WHERE particulars LIKE '%UPI%'";
$UPI_result = db_one($UPI);

$IMPS = "SELECT count(*) AS IMPS_count FROM transactions WHERE particulars LIKE '%IMPS%'";
$IMPS_result = db_one($IMPS);

$POS = "SELECT count(*) AS POS_count FROM transactions WHERE particulars LIKE '%POS%'";
$POS_result = db_one($POS);

/*$others = "SELECT count(*) AS Others_count FROM transactions WHERE particulars NOT LIKE '%POS%' OR NOT LIKE '%IMPS%' OR NOT LIKE LIKE '%UPI%' OR NOT LIKE '%RTGS%' OR NOT LIKE %Cash% OR NOT LIKE '%NEFT%'";
$others_result = db_one($others);*/

$chart_data = "[
    {
        value: ". $atm_widrawal_result['atm_count'].",
        color: '#f56954',
        highlight: '#f56954',
        label: 'atm_widrawal'
      },
      {
        value:".$neft_result['neft_count'].",
        color: '#00a65a',
        highlight: '#00a65a',
        label: 'NEFT'
      },
      {
        value: ".$cash_result['cash_count'].",
        color: '#f39c12',
        highlight: '#f39c12',
        label: 'Cash'
      },
      {
        value: ".$RTGS_result['RTGS_count'].",
        color: '#00c0ef',
        highlight: '#00c0ef',
        label: 'RTGS'
      },
      {
        value: ".$UPI_result['UPI_count'].",
        color: '#3c8dbc',
        highlight: '#3c8dbc',
        label: 'UPI'
      },
      {
        value: ".$IMPS_result['IMPS_count'].",
        color: '#9E5B4D',
        highlight: '#9E5B4D',
        label: 'IMPS'
      },
      {
        value: ".$POS_result['POS_count'].",
        color: '#F0D530',
        highlight: '#F0D530',
        label: 'POS'
      }
      ]";

      $data = $chart_data;

      //echo($data);
