import sys
import pandas as pd
import numpy as np
import networkx as nx
import scipy as sp
import pyvis
import matplotlib.pyplot as plt

[12]
df = pd.read_csv('C:\\Users\\Dhiraj\\Videos\\Fraud_Detection\\transactiondata.csv')

# sort the cases as a->b and b>a
df.sort_values(by=['sourceA', 'destA'], inplace=True, ignore_index=True)
df
# grouping

df = df.groupby(['sourceA', 'destA'], sort=False, as_index=False).sum()
df.head(10)

[13]
# graph visualization and analysis on graph

# create graph from pandas data frame
# create Graph object
G = nx.from_pandas_edgelist(df, source='sourceA',
                            target='destA',
                            edge_attr='amount',
                            create_using=nx.Graph())


# Graph visualization-Networkx
plt.figure(figsize=(11, 8))
# draw circular layout
pos = nx.circular_layout(G)
labels = nx.get_edge_attributes(G, 'amount')
nx.draw_networkx_edge_labels(G, pos, edge_labels=labels)
nx.draw(G, with_labels=True, node_color='red', edge_color='yellow', pos=pos)


# Graph visualization with-Pyvis

from pyvis.network import Network
# initialize a newtwork
net = Network(notebook=True, width='1000px', height='700px', bgcolor='#222222', font_color='white')
# pyvix intreface with newtworkx library
node_degree = dict(G.degree)
net.from_nx(G)
net.show('index.html')  # call show method and create html
# centrality measure
# degree of centrality
# betweenes centrality
# closeness centrality

sc = nx.draw_networkx_nodes(G, pos, node_size=700)

# edges
# Degree centrality

degree_dict = nx.degree_centrality(G)
degree_dict

degree_df = pd.DataFrame.from_dict(degree_dict, orient='index', columns=['centrality'])
# plot top 10 nodes
degree_df.sort_values('centrality', ascending=False)[0:9].plot(kind="bar")

# community detection
# community detection(Louvain)

import community as community_louvain

communities = community_louvain.best_partition(G)
communities
nx.set_node_attributes(G, communities, 'group')
# Graph visualization with-Pyvis

from pyvis.network import Network

# initialize a newtwork
net = Network( width='1000px', height='700px', bgcolor='#222222', font_color='white')
# pyvix intreface with newtworkx library
node_degree = dict(G.degree)
net.from_nx(G)
net.show('index.html')  # call show method and create html



