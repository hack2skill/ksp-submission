import sys
import pandas as pd
import numpy as np
import networkx as nx
import scipy as sp
import pyvis
import matplotlib.pyplot as plt


df = pd.read_csv('C:\\Users\\Dhiraj\\Videos\\Fraud_Detection\\transactiondata.csv')

#sort the cases as a->b and b>a
df.sort_values(by=['sourceA','destA'],inplace=True,ignore_index=True)
df
#grouping

df = df.groupby(['sourceA','destA'],sort=False,as_index=False).count()

# graph visualization and analysis on graph

# create graph from pandas data frame
# create Graph object
G = nx.from_pandas_edgelist(df,source='sourceA',
                             target='destA',
                             edge_attr='amount',
                             create_using = nx.Graph())

# Graph visualization-Networkx
plt.figure(figsize=(11,8))
#draw circular layout
pos = nx.circular_layout(G)
labels = nx.get_edge_attributes(G,'amount')
nx.draw_networkx_edge_labels(G,pos,edge_labels=labels)
nx.draw(G,with_labels=True,node_color='red',edge_color='yellow',pos=pos,width = [ d['amount'] for _,_, d in G.edges(data=True)])
